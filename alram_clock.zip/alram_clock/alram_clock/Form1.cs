using System;
using System.Windows.Forms;
using System.Timers;
namespace alram_clock
{
    public partial class Form1 : Form
    {
        private System.Timers.Timer timer;
        private DateTime alarmTime;
        private bool alarmActive;

        public Form1()
        {
            //initializing the object 
            InitializeComponent();
            timer = new System.Timers.Timer();
            timer.Interval = 1000;
            timer.Elapsed += Timer_Elapsed;
            timer.Enabled = true;
        }
        //timer elaspsed method
        private void Timer_Elapsed(object sender, ElapsedEventArgs e)
        {
            if (alarmActive && DateTime.Now >= alarmTime)
            {
                //condition for check alarm time is qual to current time or grater than current time
                System.Media.SystemSounds.Asterisk.Play();//for sound
                //path of image
                pictureBox1.Image = Image.FromFile("E:\\concept ll\\alram_clock\\images\\1.jpg");
                pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;//for setting properties of  image
            }


        }
        private void Form1_Load(object sender, EventArgs e)
        {
            //timer started when for load
            timer1.Start();
        }
        //Method for set the alram
        private void button1_Click(object sender, EventArgs e)
        {
            alarmTime = dateTimePicker1.Value;
            alarmActive = true;
            label1.Text = "alarm status:Start";
           
        }
        //Method for cancle the  alram 
        private void button2_Click(object sender, EventArgs e)
        {
            alarmActive = false;
            pictureBox1.Image = null;
            label1.Text = "alarm status:Stop";
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            //displaying date time to label and keep upadteing with the use of timer
            textBox1.Text = DateTime.Now.ToString("dd:mm:yyyy");
            textBox2.Text = DateTime.Now.ToString("dddd");
            textBox3.Text = DateTime.Now.ToString("hh:mm");
            textBox4.Text = DateTime.Now.ToString("ss");
            textBox5.Text = DateTime.Now.ToString("tt");
        }
    }
}